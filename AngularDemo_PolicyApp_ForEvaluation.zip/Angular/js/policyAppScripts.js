/**
 * Created by praveesh on 09-07-2016.
 */

var module = angular.module("quoteApp", ['ngRoute']);

module.config(['$routeProvider',
    function ($routeProvider) {
        $routeProvider.
            when('/newQuote', {
                templateUrl: 'pages/newQuote.html',
                controller: 'quoteController'
            }
        ).
            when('/manageQuote', {
                templateUrl: 'pages/manageQuote.html'
            }
        ).
            when('/editQuote', {
                templateUrl: 'pages/editQuote.html'
            }
        ).
            when('/comingSoon', {
                templateUrl: 'pages/comingSoon.html'
            }
        ).
            otherwise({
                redirectTo: '/newQuote'
            }
        );
    }
]);


module.factory('quoteFactory', function () {
    var factory = {};
    var quotes = [];

    factory.getQuotes = function () {
        return quotes;
    }

    factory.setQuotes = function (obj) {
        quotes.push(obj);
    }
    return factory;

});

module.controller('quoteController', function ($scope, quoteFactory) {
        $scope.quote = {};

        $scope.quote.quoteNumber = "Q" + Math.floor(Math.random() * 89999 + 10000) + "COM";
        $scope.quote.premium = "$ " + Math.floor(Math.random() * 89999 + 10000);
        $scope.quotes = quoteFactory.getQuotes();

        $scope.addQuote = function () {

            quoteFactory.setQuotes($scope.quote);
            delete $scope.quote;
            window.location = "#/manageQuote";
        };

        $scope.deleteQuote = function (deleteQuoteNumber) {
            for (i = 0; i < $scope.quotes.length; i++) {
                if ($scope.quotes[i].quoteNumber === deleteQuoteNumber) {
                    $scope.quotes.splice(i, 1);
                }
            }
        };

        $scope.editQuote = function (editQuoteNumber) {
            for (i = 0; i < $scope.quotes.length; i++) {
                if ($scope.quotes[i].quoteNumber === editQuoteNumber) {
                    $scope.quote = $scope.quotes[i];
                    break;
                }
            }

            window.location = "#/editQuote";
        };

        $scope.save = function (saveQuote) {
            for (i = 0; i < $scope.quotes.length; i++) {
                if ($scope.quotes[i].quoteNumber === saveQuote.quoteNumber) {
                    $scope.quotes[i] = $scope.quote;
                    break;
                }
            }
            window.location = "#/manageQuote";

        };

    }
);
