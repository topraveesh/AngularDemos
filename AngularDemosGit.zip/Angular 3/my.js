/**
 * Created by SPZP on 23/06/2016.
 */
var module = angular.module("sampleApp", ['ngRoute']);

    module.config(['$routeProvider',
        function($routeProvider) {
            $routeProvider.
                when('/route1', {
                    templateUrl: 'route/first.html',
                    controller: 'RouteController'
                }).
                otherwise({
                    redirectTo: '/'
                });
        }]);

    module.controller("RouteController", function($scope,$http) {
        $scope.display = function(){
          $http.get("jsonex.json")
            .success(function(data,headers,config){
              $scope.list = data.data;
            }).error(function(data){
              alert(data);
            })
        }

    })

