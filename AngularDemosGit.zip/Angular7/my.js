/**
 * Created by SPZP on 23/06/2016.
 */
var module = angular.module("serviceApp", []);

module.service("service1", function ($http) {
  this.setInfo = function () {
    info = "Service is Working";
    $http.get("jsonex.json")
              .success(function (data, headers) {
                info = data.data;
              }).error(function (data) {
                alert(data);
              })
  }

  this.getInfo = function () {
    return info;
  }
})


module.controller("serviceController", function ($scope, $http, service1, $timeout) {

  $scope.display = function () {
    service1.setInfo();
    $timeout(function(){
      $scope.list = service1.getInfo();
    }, 300);

  }

})



