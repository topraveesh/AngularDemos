/**
 * Created by SPZP on 23/06/2016.
 */
var module = angular.module("sampleApp", ['ngRoute']);

module.config(['$routeProvider',
  function ($routeProvider) {
    $routeProvider.
        when('/route1', {
          templateUrl: 'route/first.html',
          controller: 'RouteController'
        }).
        otherwise({
          redirectTo: '/'
        });
  }]);

module.factory("myFactory", function () {
  var info = {};

  //var cus = ["world"]  ;

  info.getInformation = function () {
    return info;
  }

  info.setInformation = function (obj) {
    info = obj;
  }
  return info;
})

module.controller("RouteController", function ($scope, $http, myFactory) {
  $scope.display = function () {
    $http.get("jsonex.json")
        .success(function (data, headers, config) {
          $scope.list = data.data;
        }).error(function (data) {
          alert(data);
        })

  }
  $scope.display2 = function() {
   myFactory.setInformation($scope.name);
    $scope.fname = myFactory.getInformation();
  }

})


