/**
 * Created by praveesh on 09-07-2016.
 */

var module = angular.module("quoteApp",['ngRoute']);

module.config(['$routeProvider',
    function($routeProvider){
        $routeProvider.
            when('/newQuote',{
                templateUrl:'newQuote.html',
                controller:'quoteController'
            }

        ).
            when('/editQuote',{
                templateUrl:'editQuote.html',
                controller:'quoteController'
            }

        ).
            when('/deleteQuote',{
                templateUrl:'deleteQuote.html',
                controller:'quoteController'
            }

        ).
            otherwise({
                redirectTo: '/'
            }
        );
    }
]);


module.factory('quoteFactory',function(){
    var factory = {};
    var quotes = [];

    factory.getQuotes = function(){
        return quotes;
    }

    factory.setQuotes = function(obj){
        quotes.push(obj);
    }
    return factory;

});

module.controller('quoteController',function($scope,quoteFactory){
        $scope.quote={};
        $scope.quote.quoteNumber = "Q"+Math.floor(Math.random()*89999+10000)+"COM";
        $scope.quote.premium = "$ "+Math.floor(Math.random()*89999+10000);
        $scope.quotes=quoteFactory.getQuotes();
        $scope.addQuote = function(){
            quoteFactory.setQuotes($scope.quote);
            delete $scope.quote;
            window.location = "#/editQuote";
        }
        $scope.deleteQuote = function(deleteQuoteNumber){
            for(i=0;i<$scope.quotes.length;i++){
                if($scope.quotes[i].quoteNumber === deleteQuoteNumber){
                    $scope.quotes.splice(i,1);
                }
            }
        }

    }
);
